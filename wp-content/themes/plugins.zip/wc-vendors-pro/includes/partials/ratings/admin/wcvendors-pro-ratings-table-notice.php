<?php

/**
 *  Table notice on update or delete 
 *
 *  This will display the ratings update notice
 *
 * @link       http://www.wcvendors.com
 * @since      1.0.0
 *
 * @package    WCVendors_Pro
 * @subpackage WCVendors_Pro/includes/partials/ratings
 */

echo '<div class="updated"><p>' . $message . '</p></div>';