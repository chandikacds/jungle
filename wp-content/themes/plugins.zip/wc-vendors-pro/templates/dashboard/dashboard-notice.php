<?php
/**
 * The template for displaying the vendor dashboard notice 
 *
 * Override this template by copying it to yourtheme/wc-vendors/dashboard/
 *
 * @package    WCVendors_Pro
 * @version    1.4.0
 */
?>


<div class="woocommerce-<?php echo $notice_type; ?>">
	<p><?php echo $vendor_dashboard_notice; ?></p>
</div>