<li class="commission_tab">
	<a href="#commission"><?php _e( 'Commission', $this->wcvendors_pro ) ?></a>
</li> 