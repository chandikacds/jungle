<?php

/**
 * Dashboard wrapper container 
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       http://www.wcvendors.com
 * @since      1.0.0
 *
 * @package    WCVendors_Pro
 * @subpackage WCVendors_Pro/public/partials
 */
?>

<div class="wcvendors-pro-dashboard-wrapper"> 
		
<div class="wcv-grid">