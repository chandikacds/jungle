<tr>
	<td colspan="100%">
		<h2>
			<?php _e( 'Customer note', 'wcvendors' ); ?>
		</h2>

		<p>
			<?php echo $customer_note ? $customer_note : __( 'No customer note.', 'wcvendors' ); ?>
		</p>
	</td>
</tr>